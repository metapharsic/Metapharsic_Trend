-- ========================================================
-- DMS (Document Management System) Complete Schema & Seed Data
-- ========================================================

-- Drop tables if needed
-- DROP TABLE IF EXISTS dms_audit_trail CASCADE;
-- DROP TABLE IF EXISTS dms_workflows CASCADE;
-- DROP TABLE IF EXISTS dms_versions CASCADE;
-- DROP TABLE IF EXISTS dms_documents CASCADE;

-- 1. Main Documents Table
CREATE TABLE IF NOT EXISTS dms_documents (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL, -- SOP, License, Report, Compliance, Policy, Other
    file_type VARCHAR(10) NOT NULL, -- PDF, DOCX, XLSX, etc.
    current_version VARCHAR(20) DEFAULT '1.0',
    status VARCHAR(20) DEFAULT 'Active', -- Active, Draft, Expiring, Archived, Pending, Deleted
    expiry_date DATE,
    author_id UUID,
    author_name VARCHAR(100),
    file_size BIGINT DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Document Versions Table
CREATE TABLE IF NOT EXISTS dms_versions (
    id BIGSERIAL PRIMARY KEY,
    document_id VARCHAR(50) REFERENCES dms_documents(id) ON DELETE CASCADE,
    version_label VARCHAR(20) NOT NULL,
    file_url TEXT NOT NULL,
    file_size_bytes BIGINT,
    change_log TEXT,
    uploaded_by UUID,
    uploaded_name VARCHAR(100),
    approved_by VARCHAR(100),
    approval_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Document Workflows Table
CREATE TABLE IF NOT EXISTS dms_workflows (
    id VARCHAR(50) PRIMARY KEY,
    document_id VARCHAR(50) REFERENCES dms_documents(id) ON DELETE CASCADE,
    document_title VARCHAR(255) NOT NULL,
    current_step VARCHAR(50) NOT NULL, -- Draft, Review, Approval, Published
    assigned_to VARCHAR(100),
    due_date DATE,
    status VARCHAR(20) DEFAULT 'In Progress', -- Pending, In Progress, Completed, Rejected
    comments JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Audit Trail for Compliance
CREATE TABLE IF NOT EXISTS dms_audit_trail (
    id VARCHAR(50) PRIMARY KEY,
    document_id VARCHAR(50) REFERENCES dms_documents(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL, -- Created, Modified, Viewed, Downloaded, Deleted, Approved, Rejected
    user_id VARCHAR(50),
    user_name VARCHAR(100),
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_dms_doc_category ON dms_documents(category);
CREATE INDEX IF NOT EXISTS idx_dms_doc_status ON dms_documents(status);
CREATE INDEX IF NOT EXISTS idx_dms_audit_doc_id ON dms_audit_trail(document_id);

-- ========================================================
-- SEED DATA
-- ========================================================

-- Documents Seed
INSERT INTO dms_documents (id, title, category, file_type, current_version, status, expiry_date, author_name, file_size) VALUES
('DOC-001', 'SOP for Tablet Compression', 'SOP', 'PDF', '2.1', 'Active', '2027-10-15', 'Dr. R. Singh', 2516582),
('DOC-004', 'Fire Safety Certificate', 'License', 'PDF', '1.0', 'Active', '2026-12-31', 'Safety Officer', 1153433),
('DOC-005', 'Employee Hygiene Policy', 'Policy', 'DOCX', '1.2', 'Active', '2026-11-15', 'HR Manager', 838860),
('DOC-007', 'Equipment Validation Protocol', 'Compliance', 'PDF', '1.0', 'Pending', '2026-07-25', 'Validation Team', 4718592),
('DOC-008', 'Annual Environmental Compliance Report', 'Report', 'XLSX', '1.0', 'Pending', '2026-11-25', 'EHS Head', 3355443),
('DOC-009', 'GMP Training Manual', 'Policy', 'PDF', '3.0', 'Active', '2027-06-15', 'Training Coordinator', 6081740),
('DOC-010', 'Material Safety Data Sheet - API', 'Compliance', 'PDF', '2.0', 'Active', '2027-09-25', 'QC Department', 1572864)
ON CONFLICT (id) DO NOTHING;

-- Document Versions Seed
INSERT INTO dms_versions (id, document_id, version_label, file_url, file_size_bytes, change_log, uploaded_name, approved_by, approval_date) VALUES
(1, 'DOC-001', '1.0', '/uploads/dms/DOC-001-v1.pdf', 2097152, 'Initial SOP release', 'Dr. R. Singh', 'QA Head', '2022-01-15 10:00:00+00'),
(2, 'DOC-001', '2.0', '/uploads/dms/DOC-001-v2.pdf', 2411724, 'Updated compression parameters', 'Dr. R. Singh', 'QA Head', '2023-05-10 14:30:00+00'),
(3, 'DOC-001', '2.1', '/uploads/dms/DOC-001-v2.1.pdf', 2516582, 'Minor adjustments for humidity thresholds', 'Dr. R. Singh', 'Quality Head', '2023-10-16 16:45:00+00'),
(4, 'DOC-005', '1.0', '/uploads/dms/DOC-005-v1.docx', 734003, 'Original hygiene policy draft', 'HR Manager', 'Operations Lead', '2022-06-01 09:00:00+00'),
(5, 'DOC-005', '1.2', '/uploads/dms/DOC-005-v1.2.docx', 838860, 'Updated for new statutory regulations', 'HR Manager', 'HR Director', '2023-09-12 16:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- Document Workflows Seed
INSERT INTO dms_workflows (id, document_id, document_title, current_step, assigned_to, due_date, status, created_at, updated_at) VALUES
('WF-001', 'DOC-005', 'Employee Hygiene Policy', 'Review', 'HR Manager', '2026-11-15', 'In Progress', '2026-09-12 00:00:00+00', '2026-10-20 00:00:00+00'),
('WF-002', 'DOC-008', 'Annual Environmental Compliance Report', 'Approval', 'EHS Head', '2026-11-25', 'Pending', '2026-11-01 00:00:00+00', '2026-11-01 00:00:00+00'),
('WF-003', 'DOC-001', 'SOP for Tablet Compression', 'Published', 'QA Manager', '2026-10-20', 'Completed', '2026-10-10 00:00:00+00', '2026-10-16 00:00:00+00'),
('WF-004', 'DOC-007', 'Equipment Validation Protocol', 'Approval', 'Validation Manager', '2026-07-25', 'In Progress', '2026-07-10 00:00:00+00', '2026-07-15 00:00:00+00'),
('WF-005', 'DOC-009', 'GMP Training Manual', 'Review', 'Training Coordinator', '2026-07-05', 'Completed', '2026-06-15 00:00:00+00', '2026-06-25 00:00:00+00'),
('WF-006', 'DOC-004', 'Fire Safety Certificate', 'Published', 'Safety Officer', '2026-05-25', 'Completed', '2026-05-15 00:00:00+00', '2026-05-20 00:00:00+00'),
('WF-007', 'DOC-010', 'Material Safety Data Sheet - API', 'Published', 'QC Manager', '2026-10-05', 'Completed', '2026-09-25 00:00:00+00', '2026-10-02 00:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- Document Audit Trail Seed
INSERT INTO dms_audit_trail (id, document_id, action, user_id, user_name, timestamp, ip_address, details) VALUES
('AT-001', 'DOC-001', 'Created', 'USR-001', 'Dr. R. Singh', '2026-10-15 09:30:00+00', '192.168.1.100', 'Document created with initial version 2.1'),
('AT-002', 'DOC-001', 'Viewed', 'USR-002', 'Production Manager', '2026-10-15 10:15:00+00', '192.168.1.105', 'Document viewed for implementation review'),
('AT-003', 'DOC-001', 'Modified', 'USR-001', 'Dr. R. Singh', '2026-10-16 14:20:00+00', '192.168.1.100', 'Updated version to 2.1 with new compression parameters'),
('AT-004', 'DOC-001', 'Approved', 'USR-003', 'Quality Head', '2026-10-16 16:45:00+00', '192.168.1.110', 'Document approved for implementation'),
('AT-005', 'DOC-007', 'Created', 'USR-004', 'Validation Team', '2026-07-15 11:00:00+00', '192.168.1.120', 'Equipment validation protocol created'),
('AT-006', 'DOC-007', 'Downloaded', 'USR-005', 'Validation Manager', '2026-07-18 09:15:00+00', '192.168.1.125', 'Document downloaded for review'),
('AT-007', 'DOC-009', 'Viewed', 'USR-006', 'Training Coordinator', '2026-06-20 13:30:00+00', '192.168.1.130', 'GMP training manual accessed for session preparation'),
('AT-008', 'DOC-004', 'Viewed', 'USR-007', 'Safety Officer', '2026-05-20 10:45:00+00', '192.168.1.135', 'Fire safety certificate reviewed during inspection'),
('AT-009', 'DOC-010', 'Created', 'USR-008', 'QC Department', '2026-09-30 15:20:00+00', '192.168.1.140', 'MSDS for API created with latest safety data'),
('AT-010', 'DOC-005', 'Modified', 'USR-009', 'HR Manager', '2026-09-12 16:00:00+00', '192.168.1.145', 'Employee hygiene policy updated for new regulations')
ON CONFLICT (id) DO NOTHING;
